import { Component, OnInit } from '@angular/core';

import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
 employeeList:any[];
 employee: Employee=new Employee()
  constructor(private employeeService:EmployeeService) { }

  ngOnInit() {
  }
  
  insert(data) {
    if(data.Id && data.EmployeeName && data.Email){
    alert(`Id: ${data.Id} EmployeeName: ${data.EmployeeName} Email: ${data.Email} Phone: ${data.Phone}`);
    this.employee.Id = data.Id;
    this.employee.EmployeeName = data.EmployeeName;
    this.employee.Email= data.Email;
    this.employee.Phone = data.Phone;
    
    console.log(this.employee);
    this.employeeService.setemployeeDetails(this.employee);
    }
    else{
      
    }
  }
  show(data): void {
    alert(`employee Added\nId: ${data.Id} EmployeeName: ${data.EmployeeName} Email: ${data.Email} Phone: ${data.Phone}`);
  }
}
